import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
public class Main{
	public static void main(String s[]){
		WelcomePage welcomePage=new WelcomePage();
		welcomePage.setVisible(true);
	}
}

