import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.*;
class PaintDemo extends Frame implements ActionListener{
	private TextField tf;
	private TextField tf2;
	public PaintDemo(){
		super("Java Calculator");
		Label l=new Label("Value 1");
		Label l2=new Label("Value 2");
		tf=new TextField(30);
		tf2=new TextField(30);
		Button b=new Button("+");
		Button b2=new Button("-");
		Button b3=new Button("<");
		Button b4=new Button(">");
		Button b5=new Button("Exit");
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);add(b2);
		add(b3);add(b4);add(b5);
		b.addActionListener(this);
		b2.addActionListener(this);
		b5.addActionListener(this);
		setLayout(new FlowLayout());
		setSize(270,400);
		setLocation(800,200);
		//setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
		if(s.equals("Exit")){
			System.exit(0);
		}			
	}
	public void paint(Graphics g){
		g.setColor(Color.CYAN);
		g.fillRect(0,0,270,400);
		g.drawLine(30,100,150,200);
		g.setColor(Color.RED);
		g.drawRect(30,180,100,100);
		g.setColor(Color.GREEN);
		g.fillRect(100,200,100,100);
		g.drawOval(120,220,100,100);
		g.setColor(new Color(200,100,0));
		g.fillOval(40,280,100,100);
	}
}

