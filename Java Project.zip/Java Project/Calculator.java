import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
class Calculator extends Frame implements ActionListener{
	private TextField tf;
	private TextField tf2;
	private Frame parent;
	private First first;
	public Calculator(First f){
		super("Java Calculator");
		first=f;
		Label l=new Label("Value 1");
		Label l2=new Label("Value 2");
		tf=new TextField(30);
		tf2=new TextField(30);
		Button b=new Button("+");
		Button b2=new Button("-");
		Button b3=new Button("Back");
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);add(b2);add(b3);
		b.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		setLayout(new FlowLayout());
		setSize(270,400);
		setLocation(800,200);
		//setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
		System.out.println(tf.getText());
		System.out.println(tf2.getText());
		if(s.equals("+")){
		}
		else if(s.equals("Back")){
			this.setVisible(false);
			parent.setVisible(true);
		}
	}
	public void setParent(Frame f){parent=f;}
}