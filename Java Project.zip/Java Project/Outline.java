import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
public class Outline{
	public static void main(String s[]){
		First f=new First();
		f.setVisible(true);
	}
}

