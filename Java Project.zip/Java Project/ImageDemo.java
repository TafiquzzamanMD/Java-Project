import java.awt.*;
import javax.swing.*;
import java.awt.Image;
import javax.imageio.*;
import java.awt.image.BufferedImage;
import java.io.*;

class ImageDemo extends JFrame{
    ImageDemo(){
        setLayout(new FlowLayout());
        ImageIcon ic=new ImageIcon("img.jpg");     //creates title bar icon
        this.setIconImage(ic.getImage());
        
        ImageIcon foreImage=new ImageIcon("img.jpg");
        Image im = foreImage.getImage();
        Image newimg = im.getScaledInstance(100, 100,  java.awt.Image.SCALE_SMOOTH);
        foreImage=new ImageIcon(newimg);        //creates foreground icon image
        JLabel foreGround=new JLabel(foreImage);

        JButton b1=new JButton("Ok");
        
        BufferedImage img = null;
        try {
            img = ImageIO.read(new File("back.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image backImg = img.getScaledInstance(300, 300, Image.SCALE_SMOOTH);
        ImageIcon backImageIcon = new ImageIcon(backImg);   //creates background image icon
        
        setLayout(new BorderLayout());
        JLabel back=new JLabel(backImageIcon);
        add(back);
        back.setLayout(new FlowLayout());
        back.add(b1);
        back.add(foreGround);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,300);
        //setVisible(true);
    }
}